1. Hello Ubuntu
#advanced
Score: 0.0% (Checks completed: 0.0%)
Inside the zero_day repo, create a new directory called 0x00-vagrant. Add a README.md file to this directory.

ssh into your Ubuntu VM. What does the command uname print when you run it without any option?

Type your answer into a file in the 0x00-vagrant directory and push it to GitHub. Name your file accordingly as shown below.

Repo:

GitHub repository: zero_day
Directory: 0x00-vagrant
File: 0-hello_ubuntu
