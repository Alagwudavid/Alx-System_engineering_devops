use mkdir to create the 0x03-git
create a README.md file
make sure it is not empty
