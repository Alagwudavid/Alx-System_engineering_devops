README.md up to date
